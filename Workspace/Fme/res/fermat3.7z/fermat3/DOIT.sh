# source this file into your sh before using FermaT:
# . DOIT.sh

FermaT=`pwd`
export FermaT
PATH="$FermaT/bin":$PATH
export PATH

SCHEME_LIBRARY_PATH="$FermaT/slib/"
export SCHEME_LIBRARY_PATH
SCM_INIT_PATH="$FermaT/scm/Init5f1.scm"
export SCM_INIT_PATH

