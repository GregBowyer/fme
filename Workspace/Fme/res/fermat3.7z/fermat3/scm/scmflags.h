#ifndef IMPLINIT
#define IMPLINIT "/home/martin/fermat2/scm5f1/scm/Init5f1.scm"
#endif
#define CHEAP_CONTINUATIONS
#define CAUTIOUS
